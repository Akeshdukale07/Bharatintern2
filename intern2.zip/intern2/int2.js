document.addEventListener('DOMContentLoaded', function () {
    const taskForm = document.getElementById('task-form');
    const taskList = document.getElementById('task-list');
    
    taskForm.addEventListener('submit', function (event) {
        event.preventDefault();
        
        const taskName = document.getElementById('task-name').value;
        const assignee = document.getElementById('assignee').value;
        
        if (taskName && assignee) {
            const taskItem = document.createElement('li');
            taskItem.innerHTML = `<h3>${taskName}</h3><p>Assigned to: ${assignee}</p>`;
            
            taskList.appendChild(taskItem);
            
            // You would typically send this data to the server to store in the database
            // For this simplified example, we'll just update the UI
            document.getElementById('task-name').value = '';
            document.getElementById('assignee').value = '';
        }
    });
});
